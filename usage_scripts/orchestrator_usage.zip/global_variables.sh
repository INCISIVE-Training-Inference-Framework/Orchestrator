#!/bin/bash

# --> DESCRIPTION
# It is a script that defines the global variables for the distinct use case scripts

# --> PREREQUISITES
# none

# --> GLOBAL VARIABLES
orchestrator_service_hostname="127.0.0.1:8000"
